function love.load()
    -- Load the background image once when the app starts
    background = love.graphics.newImage("Background.jpg")

    drops = {}
    for i = 1, 200 do
        drops[i] = {
            x = math.random(0, 800),
            y = math.random(-600, 0), -- Start above the screen for smooth entering
            speed = math.random(200, 600)
        }
    end
end

function love.update(dt)
    for _, d in ipairs(drops) do
        d.y = d.y + d.speed * dt
        if d.y > 600 then
            d.y = 0
            d.x = math.random(0, 800) -- Randomize X position on reset
        end
    end
end

function love.draw()
    -- 1. Draw the background image at top-left corner (0, 0)
    love.graphics.setColor(1, 1, 1)
    love.graphics.draw(background, 0, 0)

    -- 2. Set rain color (light blue/cyan) and draw drops
    love.graphics.setColor(0.6, 0.8, 1.0)
    for _, d in ipairs(drops) do
        love.graphics.line(d.x, d.y, d.x, d.y + 10)
    end

    -- Reset draw color back to white
    love.graphics.setColor(1, 1, 1)
end